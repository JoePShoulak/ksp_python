import traceback

from maneuvers.transfer import flyby_mun


try:
  flyby_mun()
  print("DIRECT_FLYBY_DONE", flush=True)
except Exception as error:
  print(f"DIRECT_FLYBY_ERROR {type(error).__name__}: {error}", flush=True)
  traceback.print_exc()
  raise
