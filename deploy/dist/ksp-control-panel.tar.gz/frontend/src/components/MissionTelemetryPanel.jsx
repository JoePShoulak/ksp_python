import Panel from "./Panel";
import VisualizationSubpanel from "./visualizations/VisualizationSubpanel";
import VesselStatus from "./visualizations/VesselStatus";
import NumericalTelemetry from "./visualizations/NumericalTelemetry";
import AscentCartesian from "./visualizations/AscentCartesian";
import AscentPolar from "./visualizations/AscentPolar";
import CameraStream from "./visualizations/CameraStream";
import KerbinSystemMap from "./visualizations/KerbinSystemMap";

function IdleTelemetryPanel() {
  return (
    <Panel title="Telemetry" popout={false}>
      <div className="idle-panel">
        <div className="idle-orb" />

        <div>
          <h3>No active vessel</h3>
          <p>
            Waiting for KSP/kRPC and an active vessel. This dashboard will
            connect automatically when telemetry becomes available.
          </p>
        </div>
      </div>
    </Panel>
  );
}

function MissionTelemetryPanel({
  telemetry,
  hasVessel,
  missionActive,
  visualResetKey,
}) {
  if (!hasVessel) {
    return <IdleTelemetryPanel />;
  }

  const hasCameras = Boolean(telemetry?.cameras?.available);
  const missionLabel = missionActive ? telemetry?.status : null;
  const vesselStatusTitle = missionLabel
    ? `Vessel Status - ${missionLabel}`
    : "Vessel Status";

  return (
    <Panel title="Telemetry" popout={false}>
      <div className="visualization-grid">
        <VisualizationSubpanel
          title={vesselStatusTitle}
          variant="primary"
          popoutName="Vessel Status">
          <VesselStatus telemetry={telemetry} />
        </VisualizationSubpanel>

        <VisualizationSubpanel
          title="Numerical Telemetry"
          variant="secondary"
          popoutName="Numerical Telemetry">
          <NumericalTelemetry telemetry={telemetry} />
        </VisualizationSubpanel>

        {hasCameras && (
          <VisualizationSubpanel
            title="Camera Feed"
            variant="camera"
            popoutName="Camera Feed">
            <CameraStream cameras={telemetry.cameras} />
          </VisualizationSubpanel>
        )}

        <VisualizationSubpanel title="Ascent - Cartesian" popoutName="Ascent Cartesian">
          <AscentCartesian
            key={`cartesian-${visualResetKey}`}
            telemetry={telemetry}
          />
        </VisualizationSubpanel>

        <VisualizationSubpanel title="Ascent - Polar" popoutName="Ascent Polar">
          <AscentPolar key={`polar-${visualResetKey}`} telemetry={telemetry} />
        </VisualizationSubpanel>

        <VisualizationSubpanel title="Kerbin System" popoutName="Kerbin System">
          <KerbinSystemMap
            key={`kerbin-${visualResetKey}`}
            telemetry={telemetry}
          />
        </VisualizationSubpanel>
      </div>
    </Panel>
  );
}

export default MissionTelemetryPanel;
